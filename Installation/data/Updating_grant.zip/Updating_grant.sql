﻿
GRANT SELECT ON TABLE ref.tg_parametre_par TO user_1;
GRANT SELECT ON TABLE ref.tr_devenirlot_dev TO user_1;
GRANT SELECT ON TABLE ref.tr_importancepatho_imp TO user_1;
GRANT SELECT ON TABLE ref.tr_localisationanatomique_loc TO user_1;
GRANT SELECT ON TABLE ref.tr_naturemarque_nmq TO user_1;
GRANT SELECT ON TABLE ref.tr_natureouvrage_nov TO user_1;
GRANT SELECT ON TABLE ref.tr_niveauechappement_ech TO user_1;
GRANT SELECT ON TABLE ref.tr_niveautaxonomique_ntx TO user_1;
GRANT SELECT ON TABLE ref.tr_parametrequalitatif_qal TO user_1;
GRANT SELECT ON TABLE ref.tr_parametrequantitatif_qan TO user_1;
GRANT SELECT ON TABLE ref.tr_pathologie_pat TO user_1;
GRANT SELECT ON TABLE ref.tr_prelevement_pre TO user_1;
GRANT SELECT ON TABLE ref.tr_stadedeveloppement_std TO user_1;
GRANT SELECT ON TABLE ref.tr_taxon_tax TO user_1;
GRANT SELECT ON TABLE ref.tr_typearretdisp_tar TO user_1;
GRANT SELECT ON TABLE ref.tr_typedc_tdc TO user_1;
GRANT SELECT ON TABLE ref.tr_typedf_tdf TO user_1;
GRANT SELECT ON TABLE ref.tr_typequantitelot_qte TO user_1;
GRANT SELECT ON TABLE ref.tr_valeurparametrequalitatif_val TO user_1;
GRANT SELECT ON TABLE ref.ts_maintenance_main TO user_1;
GRANT SELECT ON TABLE ref.ts_messager_msr TO user_1;
GRANT SELECT ON TABLE ref.ts_messagerlang_mrl TO user_1;
REVOKE ALL PRIVILEGES ON ref.ts_organisme_org FROM iav;
REVOKE ALL PRIVILEGES ON ref.ts_organisme_org FROM user_1;
GRANT SELECT ON TABLE ref.ts_organisme_org TO iav;
GRANT SELECT ON TABLE ref.ts_organisme_org TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE ref.ts_sequence_seq TO user_1;

SET search_path TO user_1, public;

GRANT ALL ON TABLE t_bilanmigrationjournalier_bjo TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE t_bilanmigrationmensuel_bme TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE t_dispositifcomptage_dic TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE t_dispositiffranchissement_dif TO user_1;
GRANT ALL ON TABLE t_lot_lot TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE t_marque_mqe TO user_1;
GRANT ALL ON TABLE t_operation_ope TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE t_operationmarquage_omq TO user_1;
GRANT ALL ON TABLE t_ouvrage_ouv TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE t_periodefonctdispositif_per TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE t_station_sta TO user_1;
GRANT ALL ON TABLE tg_dispositif_dis TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE tj_actionmarquage_act TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE tj_caracteristiquelot_car TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE tj_coefficientconversion_coe TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE tj_conditionenvironnementale_env TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE tj_dfestdestinea_dtx TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE tj_dfesttype_dft TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE tj_pathologieconstatee_pco TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE tj_prelevementlot_prl TO user_1;
GRANT ALL ON TABLE tj_stationmesure_stm TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE tj_tauxechappement_txe TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE ts_maintenance_main TO user_1;
GRANT ALL ON TABLE ts_masque_mas TO user_1;
GRANT ALL ON TABLE ts_masquecaracteristiquelot_mac TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE ts_masqueconditionsenvironnementales_mae TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE ts_masquelot_mal TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE ts_masqueope_mao TO user_1;
GRANT ALL ON TABLE ts_masqueordreaffichage_maa TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE ts_taillevideo_tav TO user_1;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE ts_taxonvideo_txv TO user_1;











